// https://www.youtube.com/watch?v=9xF89Q2052g

<template>
  <div class="container">
    <router-link class="back-link" to="/">Back to All Videos</router-link>
    <div class="video">
      <video-player
        class="video-player-box video__player"
        ref="videoPlayer"
        :options="playerOptions"
      ></video-player>
      <!-- <img :src="video.thumbnail" alt="" /> -->
      <div class="video__title">
        <h2>{{ video.name }}</h2>
      </div>
      <div class="video__description">
        <strong>Description</strong>
        <p>{{ video.description }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import "video.js/dist/video-js.css";
import { videoPlayer } from "vue-video-player";

export default {
  components: {
    videoPlayer
  },
  computed: {
    video() {
      return this.$store.state.videos.find(
        video => video.id == this.$route.params.id
      );
    },
    playerOptions() {
      return {
        // videojs options
        fluid: true,
        language: "en",
        playbackRates: [0.7, 1.0, 1.5, 2.0, 2.5, 3.0],
        sources: [
          {
            type: "video/mp4",
            src: this.video.videoUrl
          }
        ],
        poster: this.video.thumbnail
      };
    }
  }
};
</script>

<style lang="scss" scoped>
.container {
  margin: 0 auto;
  margin-top: 5rem;
  width: 80%;

  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.video {
  margin-top: 1rem;
  text-align: left;
  border-radius: var(--br-m);
  max-width: 1200px;
  box-shadow: var(--shadow-m);

  display: flex;
  flex-direction: column;

  &__player {
    // display: block;
    width: 100%;
    // max-height: 350px;
    border-top: 7px solid var(--highlight-color);
    border-radius: var(--br-m) var(--br-m) 0 0;
    // object-fit: cover;
    // object-position: top center;
  }

  &__title {
    padding: var(--space-05);
    background-color: var(--highlight-color);
  }

  &__description {
    padding: var(--space-05);
    background-color: var(--main-color);

    p {
      margin: 1rem 0;
    }
  }
}
</style>
